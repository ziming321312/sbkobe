const { Web3 } = require("web3");
const fs = require("fs");
const path = require("path");

// Retains the Web3 HTTP-provider interface while using Node's native fetch.
// This supports the host's proxy/network configuration and a per-request timeout.
class NativeHttpProvider extends Web3.providers.HttpProvider {
  async request(payload) {
    const response = await fetch(this.clientUrl, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload), signal: AbortSignal.timeout(30000)
    });
    if (!response.ok) throw new Error(`RPC HTTP ${response.status}`);
    return response.json();
  }
}

// Scan complete blocks in increasing order. No starting-block guess is used.
async function scanFirstCreation(getBlocks, end, batchSize = 100, progress = () => {}) {
  if (!Number.isSafeInteger(end) || end < 0 || !Number.isSafeInteger(batchSize) || batchSize < 1)
    throw new Error("Invalid scan range or batch size");
  let transactionsChecked = 0;
  for (let start = 0; start <= end; start += batchSize) {
    const numbers = Array.from({ length: Math.min(batchSize, end - start + 1) }, (_, i) => start + i);
    const blocks = await getBlocks(numbers);
    const byNumber = new Map(blocks.map(b => [b ? Number(BigInt(b.number)) : -1, b]));
    for (const n of numbers) {
      const block = byNumber.get(n);
      if (!block || !Array.isArray(block.transactions)) throw new Error(`Missing block ${n}; scan cannot prove earliest result`);
      const txs = [...block.transactions].sort((a, b) => Number(BigInt(a.transactionIndex) - BigInt(b.transactionIndex)));
      for (const tx of txs) {
        if (typeof tx !== "object" || !Object.hasOwn(tx, "to")) throw new Error(`Unhydrated transaction in block ${n}`);
        transactionsChecked++;
        if (tx.to === null) return {
          blockNumber: n, transactionIndex: Number(BigInt(tx.transactionIndex)),
          transactionHash: tx.hash, from: tx.from, to: tx.to, input: tx.input,
          blockHash: block.hash, timestampUTC: new Date(Number(BigInt(block.timestamp)) * 1000).toISOString(),
          blocksChecked: n + 1, transactionsChecked
        };
      }
    }
    progress(numbers[numbers.length - 1], transactionsChecked);
  }
  return null;
}

function web3BlockLoader(web3) {
  return async numbers => {
    for (let attempt = 0; attempt < 4; attempt++) {
      try {
        const batch = new web3.BatchRequest();
        for (const n of numbers) batch.add({ jsonrpc: "2.0", id: n + 1,
          method: "eth_getBlockByNumber", params: [web3.utils.toHex(n), true]
        }).catch(() => {}); // Individual errors are checked in the batch response below.
        const response = await batch.execute({ timeout: 30000 });
        if (!Array.isArray(response) || response.length !== numbers.length || response.some(r => r.error || !r.result))
          throw new Error("Incomplete or failed RPC batch");
        return response.map(r => r.result);
      } catch (_) {
        if (attempt === 3) throw new Error(`RPC batch failed at block ${numbers[0]}; check connection, credentials or quota`);
        await new Promise(resolve => setTimeout(resolve, 1000 * 2 ** attempt));
      }
    }
  };
}

// Optional quota-saving scan: gasUsedRatio is gasUsed/gasLimit, not base fee.
// A zero ratio proves that the block has no transactions: every Ethereum
// transaction consumes positive intrinsic gas, even before EIP-1559.
// Require complete history ranges; never treat missing data as an empty block.
function feeHistoryBlockLoader(getHistory, getBlocks, evidence = []) {
  return async numbers => {
    if (!numbers.length || numbers.length > 1024 ||
        numbers.some((n, i) => n !== numbers[0] + i))
      throw new Error("Fee history requires a contiguous range of 1-1024 blocks");
    const history = await getHistory(numbers.length, numbers.at(-1));
    if (Number(history.oldestBlock) !== numbers[0] ||
        !Array.isArray(history.gasUsedRatio) || history.gasUsedRatio.length !== numbers.length ||
        history.gasUsedRatio.some(r => typeof r !== "number" || !Number.isFinite(r) || r < 0 || r > 1))
      throw new Error("Incomplete or invalid fee history; cannot prove an empty range");
    const candidates = numbers.filter((_, i) => history.gasUsedRatio[i] > 0);
    const fullBlocks = [];
    // Five calls cost 400 Infura credits. Pace requests within the free tier.
    for (let i = 0; i < candidates.length; i += 5) {
      if (i > 0) await new Promise(resolve => setTimeout(resolve, 1000));
      fullBlocks.push(...await getBlocks(candidates.slice(i, i + 5)));
    }
    evidence.push({ start: numbers[0], end: numbers.at(-1),
      zeroGasBlocks: numbers.length - candidates.length, fullBlocksRequested: candidates });
    const byNumber = new Map(fullBlocks.map(b => [b ? Number(b.number) : -1, b]));
    return numbers.map((n, i) => history.gasUsedRatio[i] === 0
      ? { number: n, transactions: [], verifiedEmptyByGasUsage: true }
      : byNumber.get(n)); // A missing nonempty block is rejected by the scanner.
  };
}

async function main() {
  const key = process.env.INFURA_API_KEY;
  const rpc = process.env.ETH_RPC_URL || (key ? `https://mainnet.infura.io/v3/${key}` : null);
  if (!rpc) throw new Error("Set INFURA_API_KEY to your own key. ETH_RPC_URL is an optional fallback; no key is bundled.");
  const web3 = new Web3(new NativeHttpProvider(rpc));
  const chainId = await web3.eth.getChainId();
  if (chainId !== 1n) throw new Error("This question requires Ethereum mainnet (chain ID 1)");
  const end = process.env.END_BLOCK ? Number(process.env.END_BLOCK) : Number(await web3.eth.getBlockNumber());
  const useFeeHistory = process.env.USE_FEE_HISTORY === "1";
  const batchSize = Number(process.env.BATCH_SIZE || (useFeeHistory ? 1000 : 20));
  if (batchSize > (useFeeHistory ? 1024 : 100)) throw new Error("Batch size exceeds this scan mode's limit");
  const ranges = [];
  const fullLoader = web3BlockLoader(web3);
  const loader = useFeeHistory ? feeHistoryBlockLoader(
    (count, endBlock) => web3.eth.getFeeHistory(count, endBlock, []), fullLoader, ranges
  ) : fullLoader;
  const started = Date.now();
  const result = await scanFirstCreation(loader, end, batchSize,
    (n, count) => { if ((n + 1) % 5000 === 0) console.error(`Checked blocks 0-${n}; transactions: ${count}`); });
  if (!result) throw new Error(`No recipient-null transaction found through ${end}`);
  const receipt = await web3.eth.getTransactionReceipt(result.transactionHash);
  const record = {
    ...result, chainId: chainId.toString(),
    providerHost: new URL(rpc).hostname, // Do not disclose the URL path/API key.
    contractAddress: receipt.contractAddress,
    receiptStatus: receipt.status == null ? null : receipt.status.toString(),
    scannedFromGenesis: true,
    scanMethod: useFeeHistory ? "complete fee-history ranges plus full nonempty blocks" : "full blocks",
    ...(useFeeHistory ? { historyRequests: ranges.length,
      fullBlockRequests: ranges.reduce((n, r) => n + r.fullBlocksRequested.length, 0) } : {}),
    elapsedSeconds: (Date.now() - started) / 1000,
    checkedAtUTC: new Date().toISOString()
  };
  fs.mkdirSync(path.join(__dirname, "../evidence"), { recursive: true });
  fs.writeFileSync(path.join(__dirname, "../evidence/first-contract.json"), JSON.stringify(record, null, 2));
  if (useFeeHistory) fs.writeFileSync(path.join(__dirname, "../evidence/scan-fee-history-ranges.json"), JSON.stringify(ranges, null, 2));
  console.log(JSON.stringify(record, null, 2));
}

if (require.main === module) main().catch(e => { console.error(e.message); process.exitCode = 1; });
module.exports = { scanFirstCreation, web3BlockLoader, feeHistoryBlockLoader, NativeHttpProvider };
