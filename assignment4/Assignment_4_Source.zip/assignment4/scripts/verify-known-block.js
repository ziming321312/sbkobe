// A separate cross-check, NOT a proof that earlier blocks contain no creations.
const { Web3 } = require("web3");
const fs = require("fs");
const path = require("path");
const { NativeHttpProvider } = require("./find-first-contract");
(async () => {
  const rpc = process.env.ETH_RPC_URL || "https://ethereum-rpc.publicnode.com";
  const web3 = new Web3(new NativeHttpProvider(rpc));
  if (await web3.eth.getChainId() !== 1n) throw new Error("Wrong network");
  const block = await web3.eth.getBlock(46402, true);
  const tx = block.transactions.find(t => t.to === null);
  if (!tx) throw new Error("Expected creation transaction not found");
  const receipt = await web3.eth.getTransactionReceipt(tx.hash);
  const record = {
    blockNumber: Number(block.number), transactionIndex: Number(tx.transactionIndex),
    transactionHash: tx.hash, to: tx.to, input: tx.input,
    contractAddress: receipt.contractAddress,
    timestampUTC: new Date(Number(block.timestamp) * 1000).toISOString(),
    providerHost: new URL(rpc).hostname, scannedFromGenesis: false,
    verification: "Direct historical-block and receipt check; full Infura scan still requires student API key",
    checkedAtUTC: new Date().toISOString()
  };
  fs.writeFileSync(path.join(__dirname, "../evidence/first-contract-verified.json"), JSON.stringify(record, null, 2));
  console.log(record);
})().catch(() => { console.error("RPC verification failed; check provider availability"); process.exitCode = 1; });
