const fs = require("fs");
const path = require("path");
// solc 0.5.1 produces metadata: "" for interfaces. Truffle 5.11.5's
// console tries JSON.parse(""). Omitting only empty metadata follows its
// existing no-metadata code path; ABI and bytecode are unchanged.
const dir = path.join(__dirname, "../build/contracts");
for (const name of fs.readdirSync(dir).filter(f => f.endsWith(".json"))) {
  const file = path.join(dir, name);
  const artifact = JSON.parse(fs.readFileSync(file, "utf8"));
  if (artifact.metadata === "") {
    delete artifact.metadata;
    fs.writeFileSync(file, JSON.stringify(artifact, null, 2));
    console.log(`Omitted empty interface metadata: ${name}`);
  }
}
