pragma solidity 0.5.1;
import "./SafeMath.sol";

contract FixedVoting {
    using SafeMath for uint256;
    mapping(address => uint256) public remainingVotes;
    uint256[] public candidates;
    address payable public owner;
    bool public hasEnded = false;

    modifier notEnded() {
        require(!hasEnded, "voting ended");
        _;
    }

    constructor(uint256 amountOfCandidates) public {
        require(amountOfCandidates > 0, "no candidates");
        candidates.length = amountOfCandidates;
        owner = msg.sender;
    }

    function buyVotes() public payable notEnded {
        require(msg.value >= 1 ether, "minimum one ether");
        remainingVotes[msg.sender] = remainingVotes[msg.sender]
            .add(msg.value / 1 ether);
        uint256 change = msg.value % 1 ether;
        if (change > 0) msg.sender.transfer(change);
    }

    function vote(uint256 candidateID, uint256 amount) public notEnded {
        require(candidateID < candidates.length, "invalid candidate");
        require(remainingVotes[msg.sender] >= amount, "not enough votes");
        remainingVotes[msg.sender] = remainingVotes[msg.sender].sub(amount);
        candidates[candidateID] = candidates[candidateID].add(amount);
    }

    function payoutVotes(uint256 amount) public notEnded {
        require(remainingVotes[msg.sender] >= amount, "not enough votes");
        uint256 refund = amount.mul(1 ether);
        remainingVotes[msg.sender] = remainingVotes[msg.sender].sub(amount);
        msg.sender.transfer(refund);
    }

    function endVoting() public notEnded {
        require(msg.sender == owner, "owner only");
        hasEnded = true;
        owner.transfer(address(this).balance);
    }

    function displayBalanceInEther() public view returns (uint256) {
        return address(this).balance / 1 ether;
    }
}
