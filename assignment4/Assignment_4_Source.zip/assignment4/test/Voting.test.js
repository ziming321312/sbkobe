const FlawedVoting = artifacts.require("FlawedVoting");
const FixedVoting = artifacts.require("FixedVoting");
const truffleAssert = require("truffle-assertions");
const fs = require("fs");
const path = require("path");

contract("Voting: local reproduction and repair", accounts => {
  const [owner, buyer, attacker] = accounts;
  const ether = n => web3.utils.toWei(String(n), "ether");
  it("reproduces the unsigned-underflow exploit on a disposable local chain", async () => {
    const voting = await FlawedVoting.new(2, { from: owner });
    await voting.buyVotes({ from: buyer, value: ether(3) });
    await voting.vote(0, 1, { from: attacker });
    const wrapped = (await voting.remainingVotes(attacker)).toString();
    assert.equal(wrapped, ((1n << 256n) - 1n).toString());
    await voting.payoutVotes(3, { from: attacker });
    const balance = await web3.eth.getBalance(voting.address);
    assert.equal(balance, "0");
    fs.writeFileSync(path.join(__dirname, "../evidence/voting-exploit.json"), JSON.stringify({
      environment: "Local disposable Truffle test chain; no real funds",
      honestDepositETH: 3, attackerPurchasedVotes: 0,
      attackerRemainingVotesAfterVote: wrapped,
      attackerRefundETH: 3, contractBalanceAfterWei: balance
    }, null, 2));
  });
  it("blocks the same free-vote and refund attempts in the fixed contract", async () => {
    const voting = await FixedVoting.new(2);
    await voting.buyVotes({ from: buyer, value: ether(3) });
    await truffleAssert.reverts(voting.vote(0, 1, { from: attacker }), "not enough votes");
    await truffleAssert.reverts(voting.payoutVotes(3, { from: attacker }), "not enough votes");
    assert.equal(await web3.eth.getBalance(voting.address), ether(3));
  });
  it("buys whole votes, returns change, casts votes and refunds the remainder", async () => {
    const voting = await FixedVoting.new(2);
    await voting.buyVotes({ from: buyer, value: ether(2.5) });
    assert.equal(await web3.eth.getBalance(voting.address), ether(2));
    assert.equal((await voting.remainingVotes(buyer)).toString(), "2");
    await voting.vote(1, 1, { from: buyer });
    assert.equal((await voting.candidates(1)).toString(), "1");
    await voting.payoutVotes(1, { from: buyer });
    assert.equal((await voting.remainingVotes(buyer)).toString(), "0");
    assert.equal(await web3.eth.getBalance(voting.address), ether(1));
  });
  it("checks candidate IDs, ownership and the end state", async () => {
    const voting = await FixedVoting.new(2, { from: owner });
    await truffleAssert.reverts(voting.vote(2, 0), "invalid candidate");
    await truffleAssert.reverts(voting.endVoting({ from: buyer }), "owner only");
    await voting.endVoting({ from: owner });
    await truffleAssert.reverts(voting.buyVotes({ value: ether(1) }), "voting ended");
    await truffleAssert.reverts(voting.vote(0, 0), "voting ended");
    await truffleAssert.reverts(voting.payoutVotes(0), "voting ended");
  });
});
