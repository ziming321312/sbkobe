const XYZCoin = artifacts.require("XYZCoin");
const truffleAssert = require("truffle-assertions");

contract("XYZCoin", accounts => {
  const [owner, alice, bob, spender] = accounts;
  let token;
  beforeEach(async () => { token = await XYZCoin.new({ from: owner }); });
  const transferEvent = (tx, from, to, amount) =>
    truffleAssert.eventEmitted(tx, "Transfer", e =>
      e.from === from && e.to === to && e.value.toString() === String(amount));

  it("sets name, symbol and zero decimals", async () => {
    assert.equal(await token.name(), "XYZCoin");
    assert.equal(await token.symbol(), "XYZ");
    assert.equal((await token.decimals()).toString(), "0");
  });
  it("assigns the entire supply of 1000 to the creator", async () => {
    assert.equal((await token.totalSupply()).toString(), "1000");
    assert.equal((await token.balanceOf(owner)).toString(), "1000");
    assert.equal((await token.balanceOf(alice)).toString(), "0");
  });
  it("transfers tokens and emits Transfer", async () => {
    assert.equal(await token.transfer.call(alice, 100, { from: owner }), true);
    const tx = await token.transfer(alice, 100, { from: owner });
    assert.equal((await token.balanceOf(owner)).toString(), "900");
    assert.equal((await token.balanceOf(alice)).toString(), "100");
    transferEvent(tx, owner, alice, 100);
  });
  it("sets, reads and overwrites allowance; emits Approval", async () => {
    const tx = await token.approve(spender, 80, { from: owner });
    truffleAssert.eventEmitted(tx, "Approval", e =>
      e.owner === owner && e.spender === spender && e.value.toString() === "80");
    assert.equal((await token.allowance(owner, spender)).toString(), "80");
    await token.approve(spender, 20, { from: owner });
    assert.equal((await token.allowance(owner, spender)).toString(), "20");
  });
  it("transfers on another account's behalf and consumes allowance", async () => {
    await token.approve(spender, 80, { from: owner });
    const tx = await token.transferFrom(owner, bob, 30, { from: spender });
    assert.equal((await token.balanceOf(owner)).toString(), "970");
    assert.equal((await token.balanceOf(bob)).toString(), "30");
    assert.equal((await token.allowance(owner, spender)).toString(), "50");
    transferEvent(tx, owner, bob, 30);
  });
  it("rejects transfer with insufficient balance without changing state", async () => {
    await truffleAssert.reverts(token.transfer(bob, 1, { from: alice }), "insufficient balance");
    assert.equal((await token.balanceOf(bob)).toString(), "0");
  });
  it("rejects unauthorized nonzero transferFrom", async () => {
    await truffleAssert.reverts(token.transferFrom(owner, bob, 1, { from: spender }), "insufficient allowance");
  });
  it("rejects spending more than the approved allowance", async () => {
    await token.approve(spender, 5, { from: owner });
    await truffleAssert.reverts(token.transferFrom(owner, bob, 6, { from: spender }), "insufficient allowance");
    assert.equal((await token.allowance(owner, spender)).toString(), "5");
  });
  it("rolls allowance back if transferFrom fails for insufficient balance", async () => {
    await token.approve(spender, 10, { from: alice });
    await truffleAssert.reverts(token.transferFrom(alice, bob, 1, { from: spender }), "insufficient balance");
    assert.equal((await token.allowance(alice, spender)).toString(), "10");
  });
  it("emits Transfer for a zero-value transfer from an empty account", async () => {
    transferEvent(await token.transfer(bob, 0, { from: alice }), alice, bob, 0);
  });
  it("emits Transfer for zero-value transferFrom with zero allowance", async () => {
    transferEvent(await token.transferFrom(alice, bob, 0, { from: spender }), alice, bob, 0);
    assert.equal((await token.allowance(alice, spender)).toString(), "0");
  });
  it("emits Approval when allowance is reset to zero", async () => {
    await token.approve(spender, 5, { from: owner });
    const tx = await token.approve(spender, 0, { from: owner });
    truffleAssert.eventEmitted(tx, "Approval", e => e.value.toString() === "0");
    assert.equal((await token.allowance(owner, spender)).toString(), "0");
  });
  it("handles self-transfers without creating tokens", async () => {
    await token.transfer(owner, 77, { from: owner });
    assert.equal((await token.balanceOf(owner)).toString(), "1000");
  });
  it("keeps supply fixed and rejects a zero recipient", async () => {
    await truffleAssert.reverts(token.transfer("0x0000000000000000000000000000000000000000", 1), "zero address");
    assert.equal((await token.totalSupply()).toString(), "1000");
  });
});
