# Assignment / Lab 4

GEC Academy - Assignment / Lab 4
Wang, Ziming

Run with Node.js 24+ (validated with Node 26.8.1):
  npm ci
  npm run compile
  npm test
  npm run test:scanner

Interactive local deployment:
  npm run develop
Then type: migrate, test, .exit (one command per line).

Results: solc 0.5.1; optimizer on (200 runs); Byzantium compiler target.
18 contract tests passed; 8 scanner tests passed. Truffle develop migration
succeeded on local network 5777; XYZCoin used 649723 gas in block 3.
See evidence/develop-migration.txt, develop-tests.txt and voting-exploit.json.
The empty metadata emitted for interfaces by solc 0.5.1 is omitted after
compilation by normalize-artifacts.js; no ABI or bytecode is changed.
Ganache used its working JavaScript fallback for Node 26.

A complete from-genesis scan using the student's verified Infura account
was executed on November 4, 2026. It found the first recipient-null
transaction in block 46402. See evidence/first-contract.json and
infura-scan.txt; scan-fee-history-ranges.json records all scanned ranges.
The earlier public-RPC targeted check is retained as separate evidence.

Set INFURA_API_KEY to your own key in the environment, then run:
  USE_FEE_HISTORY=1 npm run scan

This quota-saving mode covers contiguous ranges from block 0, checking
eth_feeHistory gasUsedRatio (not baseFeePerGas) to establish empty blocks.
Every transaction consumes positive gas. It retrieves full transactions for
all nonempty blocks and inspects them in ascending block/index order.
Shortened history or missing blocks causes an error, never a silent skip.
The default full-block scan is still available with npm run scan, but about
46,403 blocks at 80 credits each exceed the free 3M-credit daily allowance.
No credentials are bundled. BATCH_SIZE defaults to 1000 for fee-history mode
(max 1024), and 20 for full-block mode (max 100). The completed historical
answer concerns a null recipient, even when deployment yields no runtime code.

Source is in contracts/, migrations/, test/, test-node/ and scripts/.
build/contracts/ contains generated compiler/deployment artifacts.
Etherscan CSV data and execution logs are in evidence/.
Review the PDF and sign it yourself. AI assistance is disclosed in the report.

AI assistance was used for implementation, explanations, testing and preparation.
The report and personal signature are handled separately through the course LMS.
