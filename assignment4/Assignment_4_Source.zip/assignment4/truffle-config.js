let testProvider;
module.exports = {
  networks: {
    development: { host: "127.0.0.1", port: 8545, network_id: "*" },
    develop: { host: "127.0.0.1", port: 9545, network_id: 5777 },
    test: {
      network_id: "*",
      provider: () => {
        if (!testProvider) testProvider = require("ganache").provider({
          logging: { quiet: true }, wallet: { totalAccounts: 10 },
          chain: { chainId: 1337 }
        });
        return testProvider;
      }
    }
  },
  compilers: {
    solc: {
      // npm locks this local compiler to exactly 0.5.1.
      version: require.resolve("solc/soljson.js"),
      settings: { optimizer: { enabled: true, runs: 200 }, evmVersion: "byzantium" }
    }
  },
  mocha: { timeout: 100000 }
};
