const { test } = require("node:test");
const assert = require("node:assert/strict");
const { scanFirstCreation, feeHistoryBlockLoader } = require("../scripts/find-first-contract");
const block = (n, txs = []) => ({ number: "0x" + n.toString(16), hash: "block" + n, timestamp: "0x1", transactions: txs });
const tx = (i, to, hash) => ({ transactionIndex: "0x" + i.toString(16), to, hash, from: "sender", input: "0x" });
test("selects earliest block and transaction despite out-of-order RPC responses", async () => {
  const get = async ns => ns.map(n => block(n, n === 2 ? [tx(1, null, "later"), tx(0, null, "first")] : n === 3 ? [tx(0, null, "latest")] : [])).reverse();
  const result = await scanFirstCreation(get, 4, 4);
  assert.equal(result.blockNumber, 2); assert.equal(result.transactionHash, "first");
  assert.equal(result.blocksChecked, 3);
});
test("does not mistake an ordinary zero-address transfer for contract creation", async () => {
  const result = await scanFirstCreation(async ns => ns.map(n => block(n, [tx(0, "0x0000000000000000000000000000000000000000", "ordinary")])), 2);
  assert.equal(result, null);
});
test("fails rather than silently skipping a missing block", async () => {
  await assert.rejects(scanFirstCreation(async () => [block(0), block(2)], 2), /Missing block 1/);
});
test("accepts empty-initcode creation, which still has a null recipient", async () => {
  const r = await scanFirstCreation(async () => [block(0, [tx(0, null, "empty")])], 0);
  assert.equal(r.input, "0x"); assert.equal(r.transactionHash, "empty");
});
test("fee history skips only proven empty blocks and finds the earliest creation", async () => {
  const requested = [];
  const loader = feeHistoryBlockLoader(async () => ({ oldestBlock: 0n, gasUsedRatio: [0, .2, 0, .3] }),
    async ns => { requested.push(...ns); return ns.map(n => block(n, [tx(0, n === 3 ? null : "ordinary", "tx" + n)])).reverse(); });
  const r = await scanFirstCreation(loader, 3, 4);
  assert.deepEqual(requested, [1, 3]); assert.equal(r.blockNumber, 3);
  assert.equal(r.blocksChecked, 4); assert.equal(r.transactionsChecked, 2);
});
test("shortened or shifted fee history cannot silently skip earlier blocks", async () => {
  for (const history of [{oldestBlock: 1n, gasUsedRatio: [0, 0]}, {oldestBlock: 0n, gasUsedRatio: [0]}]) {
    const loader = feeHistoryBlockLoader(async () => history, async () => []);
    await assert.rejects(scanFirstCreation(loader, 1, 2), /Incomplete or invalid/);
  }
});
test("invalid gas ratios are rejected rather than interpreted as empty", async () => {
  for (const ratio of [NaN, -1, 1.1, "0"]) {
    const loader = feeHistoryBlockLoader(async () => ({oldestBlock: 0n, gasUsedRatio: [ratio]}), async () => []);
    await assert.rejects(scanFirstCreation(loader, 0, 1), /Incomplete or invalid/);
  }
});
test("missing nonempty blocks still fail in the quota-saving mode", async () => {
  const loader = feeHistoryBlockLoader(async () => ({oldestBlock: 0n, gasUsedRatio: [0, .1]}), async () => []);
  await assert.rejects(scanFirstCreation(loader, 1, 2), /Missing block 1/);
});
